
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;


entity DFlipFlop is
    Port ( D : in  STD_LOGIC;
           Q : out  STD_LOGIC;
           clk : in  STD_LOGIC;
           res : in  STD_LOGIC);
end DFlipFlop;

architecture Behavioral of DFlipFlop is

begin

process (clk)
begin 
	if rising_edge(clk) then
		if (res = '1' or D = '0') then
			Q <= '0';
		else
			Q <= '1';
		end if;
	end if;
end process;

end Behavioral;

