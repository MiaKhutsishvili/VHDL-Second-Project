----------------------------------------------------------------------------------
-- Name:           Kimia Khudsiani
-- Stdent number:  40223030
-- Create Date:    14:57:15 06/12/2025 
-- Module Name:    Be - Behavioral 
-- Project Name: 	 VHDL 2
-- Description:    Part Be
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Be is
    Port ( unlock : in  STD_LOGIC;
           Botton : in  STD_LOGIC;
           clk : in  STD_LOGIC;
           C_unlock : in  STD_LOGIC;
           Reset : in  STD_LOGIC;
           s_i : in  STD_LOGIC;
           Data_Clk : in  STD_LOGIC;
           y : out  STD_LOGIC);
end Be;

architecture Structural of Be is

signal t_i: STD_LOGIC;
signal res: STD_LOGIC;
signal J_sel: STD_LOGIC;
signal q: unsigned (31 downto 0) := (others => '0');
signal BottonDown: STD_LOGIC;
signal flipflop_1_out: STD_LOGIC;
signal x: unsigned (2 downto 0) := (others => '0');
signal cnt16: unsigned (15 downto 0) := (others => '0');
signal SIPO16_out: STD_LOGIC_VECTOR (15 downto 0);
signal mux81_inputs: STD_LOGIC_VECTOR (0 to 7);
signal mux81_output: STD_LOGIC;
signal mux21_output: STD_LOGIC;
signal k: STD_LOGIC;
signal equalCheck: STD_LOGIC;
signal J: STD_LOGIC;
signal clk3bitcounter: STD_LOGIC;
signal res16bitcounter: STD_LOGIC;
signal JKFRes: STD_LOGIC;

begin

--
res <= not(Reset);

--
t_i <= not(unlock);

--
J_sel <= not(C_unlock);

-- 32Bit Counter
U2: entity work.Counter32(Behavioral)
        port map (
				res => res,
            clk  => clk,
            q => q
        );

-- Botton
U1: entity work.DeBouncer(Behavioral)
        port map (
            BottonClick  => Botton,
            BottonClk  => q(11),
            BottonPress => BottonDown
        );


-- D Flip Flop
U3: entity work.DFlipFlop(Behavioral)
        port map (
            Q  => flipflop_1_out,
            clk  => q(11),
				res => res,
            D => BottonDown
        );

-- 3Bit Counter
clk3bitcounter <= BottonDown and (not (flipflop_1_out));
U4: entity work.Counter3(Behavioral)
        port map (
            clk  => clk3bitcounter,
				res => res,
            x => x
        );

-- Mux 8:1
mux81_inputs <= q(31) & q(27) & q(23) & q(19) & q(15) & q(11) & q(7) & q(3);
mux81_output <= mux81_inputs(to_integer(x));

-- Mux 2:1
U9: entity work.Mux21(Behavioral)
        port map (
            data  => mux81_output,
				selector => k,
            output => mux21_output
        );

-- 16Bit counter
res16bitcounter <= res and equalCheck;
U5: entity work.Counter16(Behavioral)
        port map (
            clk  => mux21_output,
				res => res16bitcounter,
            output => cnt16
        );

-- Timer
U6: entity work.Input16(Behavioral)
        port map (
            clk  => Data_Clk,
				res => res,
            InputNum => SIPO16_out,
				D => s_i
        );
		  
-- Comparer
U7: entity work.Comparer(Behavioral)
        port map (
            A  => unsigned(SIPO16_out),
				B => cnt16,
				check => equalCheck
        );
		  
-- J K Flipflop
J <= not(J_sel); -- K is 0
JKFRes <= res or t_i;
U8: entity work.JKFlipFlop(Behavioral)
        port map (
            J  => J,
				K => '0',
				clk => equalCheck,
				Q0 => k,
				Q => k,
				res => JKFRes
        );
y <= k;
end Structural;

