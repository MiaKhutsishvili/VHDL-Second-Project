
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity Input16 is
    Port ( D : in  STD_LOGIC;
           clk : in  STD_LOGIC;
			  res : in STD_LOGIC;
           InputNum : out STD_LOGIC_VECTOR (15 downto 0));
end Input16;

architecture Behavioral of Input16 is

signal SIPO16_out: STD_LOGIC_VECTOR (15 downto 0);

begin

process (clk, res)
begin
	if rising_edge(clk) then
		if res = '1' then	
			SIPO16_out <= (others => '0');
		else
			SIPO16_out <= SIPO16_out(14 downto 0) & D;
		end if;
	end if;
end process;
InputNum <= SIPO16_out;

end Behavioral;

