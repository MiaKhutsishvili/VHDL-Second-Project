library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Counter3 is
    Port ( clk : in  STD_LOGIC;
           res : in  STD_LOGIC;
           x : out unsigned (2 downto 0));
end Counter3;

architecture Behavioral of Counter3 is

signal cnt: unsigned (2 downto 0);
begin

process (clk, res)
begin
	if rising_edge(clk) then
		if (cnt = "111" or res = '1') then
			cnt <= (others => '0');
		else 
			cnt <= cnt + 1;
		end if;
	end if;
end process;
x <= cnt;

end Behavioral;

