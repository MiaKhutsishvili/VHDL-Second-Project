
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;


entity DeBouncer is
    Port ( BottonClick : in  STD_LOGIC;
           BottonClk : in  STD_LOGIC;
           BottonPress : out  STD_LOGIC);
end DeBouncer;

architecture Behavioral of DeBouncer is

signal SIPO8_out: STD_LOGIC_VECTOR (7 downto 0);

begin

process (BottonClk, SIPO8_out)
begin
	if rising_edge(BottonClk) then
		SIPO8_out <= SIPO8_out(6 downto 0) & BottonClick;
	end if;
	if SIPO8_out = "11111111" then 
		BottonPress <= '1';
	else
		BottonPress <= '0';
	end if;
end process;

end Behavioral;

