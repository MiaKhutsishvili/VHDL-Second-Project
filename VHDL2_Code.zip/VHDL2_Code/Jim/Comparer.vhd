
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Comparer is
    Port ( A : in  unsigned (15 downto 0);
           B : in  unsigned (15 downto 0);
           check : out STD_LOGIC);
end Comparer;

architecture Behavioral of Comparer is

begin

process (A, B)
begin
	if A = B then
		check <= '1';
	else 
		check <= '0';
	end if;
end process;

end Behavioral;

