
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity JKFlipFlop is
    Port ( J : in  STD_LOGIC;
           K : in  STD_LOGIC;
           res : in  STD_LOGIC;
           Q : out  STD_LOGIC;
			  Q0 : in STD_LOGIC; -- Last Q
           clk : in  STD_LOGIC);
end JKFlipFlop;

architecture Behavioral of JKFlipFlop is

signal JK : STD_LOGIC_VECTOR (1 downto 0);

begin

JK <= J & K;

process (clk, JK)
begin
	if rising_edge (clk) then
		if res = '1' then 
			Q <= '0';
		else
			case JK is
				when "11" =>
					Q <= not(Q0);
				when "01" =>
					Q <= '0';
				when "10" =>
					Q <= '1'; 
				when others =>
					null;
			end case;
		end if;
	end if;
end process;

end Behavioral;

