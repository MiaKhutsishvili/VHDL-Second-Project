
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity Counter16 is
    Port ( clk : in  STD_LOGIC;
           output : out unsigned (15 downto 0);
           res : in  STD_LOGIC);
end Counter16;

architecture Behavioral of Counter16 is

signal cnt16 : unsigned (15 downto 0);

begin

process (clk, res)
begin
	if rising_edge(clk) then
		if (cnt16 = "1111111111111111" or res = '1') then
			cnt16 <= "0000000000000000";
		else 
			cnt16 <= cnt16 + 1;
		end if;
	end if;
end process;
output <= cnt16;

end Behavioral;

