library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Mux21 is
    Port ( data : in  STD_LOGIC;
           selector : in  STD_LOGIC;
           output : out  STD_LOGIC);
end Mux21;

architecture Behavioral of Mux21 is

begin

process (selector)
begin
	if selector = '0' then
		output <= data;
	else
		output <= '0';
	end if;
end process;

end Behavioral;

