----------------------------------------------------------------------------------
-- Name:           Kimia Khudsiani
-- Stdent number:  40223030
-- Create Date:    14:57:15 06/12/2025 
-- Module Name:    Alef - Behavioral 
-- Project Name: 	 VHDL 2
-- Description:    Part Alef
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Alef is
    Port ( unlock : in  STD_LOGIC;
           Botton : in  STD_LOGIC;
           clk : in  STD_LOGIC;
           C_unlock : in  STD_LOGIC;
           Reset : in  STD_LOGIC;
           s_i : in  STD_LOGIC;
           Data_Clk : in  STD_LOGIC;
           y : out  STD_LOGIC);
end Alef;

architecture Behavioral of Alef is

signal t_i: STD_LOGIC;
signal res: STD_LOGIC;
signal J_sel: STD_LOGIC;
signal q: unsigned (31 downto 0) := (others => '0');
signal max_cnt: unsigned (31 downto 0) := (others => '1');
signal SIPO8_out: STD_LOGIC_VECTOR (7 downto 0);
signal BottonDown: STD_LOGIC;
signal flipflop_1_out: STD_LOGIC;
signal x: unsigned (2 downto 0) := (others => '0');
signal mux81_inputs: STD_LOGIC_VECTOR (0 to 7);
signal mux81_output: STD_LOGIC;
signal mux21_output: STD_LOGIC;
signal k: STD_LOGIC;
signal cnt16: unsigned (15 downto 0) := (others => '0');
signal SIPO16_out: STD_LOGIC_VECTOR (15 downto 0);
signal equalCheck: STD_LOGIC;
signal J: STD_LOGIC;
signal clk3bitcounter: STD_LOGIC;

begin

--
res <= not(Reset);

--
t_i <= not(unlock);

--
J_sel <= not(C_unlock);

-- 32Bit Counter
process (clk, res)
begin
	if rising_edge (clk) then
		if (q = max_cnt or res = '1') then
			q <= (others => '0');
		else 
			q <= q + 1;
		end if;
	end if;
end process;

-- SIPO 8Bit_Out
process (q(11), SIPO8_out)
begin
	if rising_edge(q(11)) then
		SIPO8_out <= SIPO8_out(6 downto 0) & Botton;
	end if;
	if SIPO8_out = "11111111" then 
		BottonDown <= '1';
	else
		BottonDown <= '0';
	end if;
end process;


-- D Flip Flop
process (q(11), BottonDown)
begin 
	if rising_edge(q(11)) then
		if res = '1' then
			flipflop_1_out <= '0';
		elsif BottonDown = '1' then
			flipflop_1_out <= '1';
		else
			flipflop_1_out <= '0';
		end if;
	end if;
end process;

-- 3Bit Counter
process (flipflop_1_out, BottonDown, res, x)
begin
	clk3bitcounter <= BottonDown and (not (flipflop_1_out));
	if rising_edge(clk3bitcounter) then
		if (x = "111" or res = '1') then
			x <= (others => '0');
		else 
			x <= x + 1;
		end if;
	end if;
end process;

-- Mux 8:1
mux81_inputs <= q(31) & q(27) & q(23) & q(19) & q(15) & q(11) & q(7) & q(3);
mux81_output <= mux81_inputs(to_integer(x));

-- Mux 2:1
process (k, mux81_output)
begin
	if k = '0' then
		mux21_output <= mux81_output;
	else
		mux21_output <= '0';
	end if;
end process;

-- 16Bit counter
process (mux21_output, res, equalCheck)
begin
	if rising_edge(mux21_output) then
		if (cnt16 = "1111111111111111" or (res = '1' and equalCheck = '1')) then
			cnt16 <= "0000000000000000";
		else 
			cnt16 <= cnt16 + 1;
		end if;
	end if;
end process;

-- SIPO 16Bit
process (Data_Clk, res)
begin
	if rising_edge(Data_Clk) then
		if res = '1' then	
			SIPO16_out <= (others => '0');
		else
			SIPO16_out <= SIPO16_out(14 downto 0) & s_i;
		end if;
	end if;
end process;

-- Comparer
process (SIPO16_out, cnt16)
begin
	if unsigned(SIPO16_out) = cnt16 then
		equalCheck <= '1';
	else 
		equalCheck <= '0';
	end if;
end process;

-- J K Flipflop
J <= not(J_sel); -- K is 0
process (J, equalCheck, res, t_i)
begin 
	if rising_edge (equalCheck) then
		if (J = '0' or (res = '1' or t_i = '1')) then
			k <= '0';
		else 
			k <= not(k);
		end if;
	end if;
end process;
y <= k;

end Behavioral;

