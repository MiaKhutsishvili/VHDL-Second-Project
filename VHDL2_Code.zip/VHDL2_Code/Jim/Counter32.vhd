
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity Counter32 is
    Port ( clk : in  STD_LOGIC;
           res : in  STD_LOGIC;
           q : out unsigned (31 downto 0));
end Counter32;

architecture Behavioral of Counter32 is

signal Q1: unsigned (31 downto 0) := (others => '0');
signal max_cnt: unsigned (31 downto 0) := (others => '1');

begin

process (clk, res)
begin
	if rising_edge (clk) then
		if (Q1 = max_cnt or res = '1') then
			Q1 <= (others => '0');
		else 
			Q1 <= Q1 + 1;
		end if;
	end if;
end process;
q <= Q1;

end Behavioral;

